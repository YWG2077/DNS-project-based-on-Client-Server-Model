int main(void) {
  asm(
    "movw R2, #0x8110\n\t"
    "movt R2, #0x4802\n\t"
    "mov  R1, #0x8080\n\t"
    "str  R1, [R2]\n\t"
    "movw R2, #0x8100\n\t"
    "movt R2, #0x4802\n\t"
    "mov  R1, #0x0003\n\t"
    "str  R1, [R2]\n\t"
    "movw LR, #0x0325\n\t"
    "movt LR, #0x0800\n\t"
    "bx LR\n\t"
  );
}
