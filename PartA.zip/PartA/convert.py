def xor_and_convert(input_str):
    hex_values = input_str.strip().split()
    result = []

    for hex_val in hex_values:
        num = int(hex_val, 16)       # Convert hex to integer
        xor_result = num ^ 0x42      # XOR with 0x42
        result.append(f'{xor_result:02x}')  # Format as 2-digit hex

    return ' '.join(result)

# Example usage:
input_str = "48 f2 10 12 c4 f6 02 02 48 f2 80 01 11 60 48 f2 00 12 c4 f6 02 02 4f f0 03 01 11 60 40 f2 25 3e c0 f6 00 0e 70 47"
output_str = xor_and_convert(input_str)
print("XORed result:", output_str)
